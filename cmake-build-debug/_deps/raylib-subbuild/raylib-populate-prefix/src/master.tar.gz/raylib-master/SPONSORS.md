## raylib GitHub Sponsors

### Current raylib GitHub Sponsors (raylib 4.0 release)

The following people are currently [**sponsoring raylib**](https://github.com/sponsors/raysan5) with a generous donation to allow improving and growing the project!

 - Eric J. ([@ProfJski](https://github.com/ProfJski))
 - Zach Geis ([@zacgeis](https://github.com/zacgeis))
 - minirop ([@minirop](https://github.com/minirop))
 - Daniel Gómez ([@Koocachookies](https://github.com/Koocachookies))
 - Marc Agüera ([@maguera93](https://github.com/maguera93))
 - Robin Mattheussen ([@romatthe](https://github.com/romatthe))
 - Grant Haywood ([@cinterloper](https://github.com/cinterloper))
 - Terry Nguyen ([@terrehbyte](https://github.com/terrehbyte))
 - Tommi Sinivuo ([@TommiSinivuo](https://github.com/TommiSinivuo))
 - Richard Urbanec ([@Poryg1](https://github.com/Poryg1))
 - pmgl ([@pmgl](https://github.com/pmgl))
 - cob ([@majorcob](https://github.com/majorcob))
 - Samuel Batista ([@gamedevsam](https://github.com/gamedevsam))
 - Merlyn Morgan-Graham ([@kavika13](https://github.com/kavika13))
 - linus ([@hochbaum](https://github.com/hochbaum))
 - Níckolas Daniel da Silva ([@nawarian](https://github.com/nawarian) - [thephp.website](https://thephp.website/))
 - kenzie ([@sme-ek](https://github.com/sme-ek))
 - Allan Regush ([@AllanRegush](https://github.com/AllanRegush))
 - Jeffery Myers ([@JeffM2501](https://github.com/JeffM2501))
 - Ryan Roden-Corrent ([@rcorre](https://github.com/rcorre))
 - michaelfiber ([@michaelfiber](https://github.com/michaelfiber))
 - Nikhilesh S ([@nikki93](https://github.com/nikki93))
 - kevinabraun ([@kevinabraun](https://github.com/kevinabraun))
 - Matthew Owens ([@MatthewOwens](https://github.com/MatthewOwens))
 - Tim Eilers ([@eilerstim](https://github.com/eilerstim))
 - Laurentino Luna ([@catmanl](https://github.com/catmanl))

### Past raylib GitHub Sponsors

The following people has **sponsored raylib** in the past, allowing the project to reach current amazing state.

 - Jonathan Johnson ([@ecton](https://github.com/ecton))
 - Rudy Faile ([@rfaile313](https://github.com/rfaile313)) - https://rudyfaile.com/
 - frithrah ([@frithrah](https://github.com/frithrah))
 - Jens Pitkänen ([@neonmoe](https://github.com/neonmoe))
 - Rahul Nair ([@rahulunair](https://github.com/rahulunair)) 
 - albatros-hmd ([@albatros-hmd](https://github.com/albatros-hmd))
 - Benjamin Stigsen ([@BenStigsen](https://github.com/BenStigsen))
 - Louis Johnson ([@louisgjohnson](https://github.com/louisgjohnson))
 - Dani Martin ([@danimartin82](https://github.com/danimartin82))
 - Joakim Wennergren ([@joakimwennergren](https://github.com/joakimwennergren))
 - Alexandre Chêne ([@kooparse](https://github.com/kooparse))
 - daddio69 ([@daddio69](https://github.com/daddio69))
 - James Ghawaly ([@jghawaly](https://github.com/jghawaly))
 - jack ([@Jack-Ji](https://github.com/Jack-Ji))
 - Guido Offermans ([@jghawaly](https://github.com/GuidoOffermans))
 - devdad ([@devdad](https://github.com/devdad))
 - Pau Fernández ([@pauek](https://github.com/pauek))
 - Sergio ([@anidealgift](https://github.com/anidealgift))
 - Snowminx ([@Gamerfiend](https://github.com/Gamerfiend))
 - NimbusFox ([@NimbusFox](https://github.com/NimbusFox))
 - Shylie ([@Shylie](https://github.com/Shylie))
 - Livio Dal Maso ([@Humeur](https://github.com/Humeur))
 - Diego Vaccher ([@denny0754](https://github.com/denny0754))
 - Ricardo Alcantara ([@ricardoalcantara](https://github.com/ricardoalcantara))
 - Toby4213 ([@Toby4213](https://github.com/Toby4213))

### Notes for Current/Past raylib Sponsor

 - If you are not on the list, feel free to send a PR to be added (if desired).
 - If you want your personal webpage or project listed, feel free to send a PR to be added.
 - If you prefer not to be in this list, feel free to send a PR to be remove.

